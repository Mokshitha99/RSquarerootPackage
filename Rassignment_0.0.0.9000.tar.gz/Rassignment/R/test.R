#'
#'we square a number
#'
#'
#'@return returns x*x

square=function(x)
{
  y=x*x
  return(y)
}
